package master.fss.calculatrice.service;

import master.fss.calculatrice.metier.Calculatrice;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/calcul")
public class CalculRestController {

    private final Calculatrice calculatrice;

    public CalculRestController(Calculatrice calculatrice) {
        this.calculatrice = calculatrice;
    }

    @GetMapping("/somme")
    public double somme(@RequestParam double a, @RequestParam double b) {
        return calculatrice.somme(a, b);
    }

    @GetMapping("/test")
    public String test() {
        return "Calculatrice OK!";
    }
}
