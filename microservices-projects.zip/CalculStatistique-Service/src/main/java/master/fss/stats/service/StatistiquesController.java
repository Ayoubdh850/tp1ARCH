package master.fss.stats.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/stats")
public class StatistiquesController {

    private final RestTemplate restTemplate;

    @Value("${calculatrice.service.url}")
    private String calcUrl;

    public StatistiquesController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/moyenne")
    public double moyenne(@RequestParam double a, @RequestParam double b) {

        String url = calcUrl + "/api/calcul/somme?a=" + a + "&b=" + b;

        Double somme = restTemplate.getForObject(url, Double.class);

        return somme / 2;
    }
}
