package master.fss.stats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculStatistiqueServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(CalculStatistiqueServiceApplication.class, args);
    }
}
